from setuptools import setup

setup(name='pycool',
      version='0.1',
      description='high-level functions',
      url='http://github.com/anisg/pytool',
      author='A G',
      author_email='nope@nope.com',
      license='MIT',
      packages=['pycool'],
      zip_safe=False)
